CREATE VIEW Top_Paladins_Rank as
SELECT
 top_distance.Name as Name,
 coalesce(world_list.World,'No World') as World,
 coalesce(world_list.PvP_Type, 'No Title World') as PVP_Type,
 top_distance.Rank as Distance_Rank,
 --coalesce(char_infor.Level,0) as Char_Level,
 coalesce(top_shielding.Rank,0) as Shielding_Rank,
 --coalesce(char_infor.Achievement,0) as Achievement_CI,
 coalesce(top_achievements.Rank,0) as Achievements_Rank,
 coalesce(top_loyalty.Rank,0) as Loyalty_Rank,
 --coalesce(top_loyalty.Title,'No Title') as Loyalty_Title,
 coalesce(top_magiclevel.Rank,0) as Magic_Level_Rank,
 coalesce(top_fist.Rank,0) as Fist_Rank,
 coalesce(top_sword.Rank,0) as Sword_Rank,
 coalesce(top_club.Rank,0) as Club_Rank,
 coalesce(top_axe.Rank,0) as Axe_Rank,
 coalesce(top_fishing.Rank,0) as Fishing_Rank
FROM top_distance
LEFT JOIN top_magiclevel
ON top_magiclevel.Name = top_distance.Name
LEFT JOIN top_shielding
ON top_shielding.Name = top_distance.Name
LEFT JOIN top_achievements
ON top_achievements.Name = top_distance.Name
LEFT JOIN top_loyalty
ON top_loyalty.Name = top_distance.Name
LEFT JOIN top_experience
ON top_experience.Name = top_distance.Name
LEFT JOIN top_axe
ON top_axe.Name = top_distance.Name
LEFT JOIN top_sword
ON top_sword.Name = top_distance.Name
LEFT JOIN top_club
ON top_club.Name = top_distance.Name
LEFT JOIN top_fishing
ON top_fishing.Name = top_distance.Name
LEFT JOIN top_fist
ON top_fist.Name = top_distance.Name
LEFT JOIN char_infor
ON top_distance.Name = char_infor.Name
LEFT JOIN world_list
ON world_list.World = top_distance.World
ORDER BY world_list.World;

