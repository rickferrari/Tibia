CREATE TRIGGER pop_topMagicLevel_history
AFTER INSERT ON top_magiclevel
BEGIN
INSERT INTO top_magiclevel_history
(
  Rank,
  Name,
  Vocation,
  Level,
  World,
  Link,
  Extract_data
)
 VALUES
(
  new.Rank,
  new.Name,
  new.Vocation,
  new.Level,
  new.World,
  new.Link,
  new.Extract_data
);
END;

