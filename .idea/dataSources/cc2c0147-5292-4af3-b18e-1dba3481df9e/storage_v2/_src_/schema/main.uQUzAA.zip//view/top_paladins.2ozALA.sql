CREATE VIEW Top_Paladins as
SELECT
 top_distance.Rank as Rank,
 top_distance.Name as Name,
 top_distance.Level as Distance,
 coalesce(char_infor.Level,0) as Char_Level,
 coalesce(top_shielding.Level,0) as Shielding,
 coalesce(char_infor.Achievement,0) as Achievement_CI,
 coalesce(top_achievements.Points,0) as Achievements_TOP,
 coalesce(top_loyalty.Points,0) as Loyalty_Points,
 coalesce(top_loyalty.Title,'No Title') as Loyalty_Title,
 coalesce(top_magiclevel.Level,0) as Magic_Level,
 coalesce(top_experience.Level,0) as Experience_TOP,
 coalesce(top_fist.Level,0) as Fist,
 coalesce(top_sword.Level,0) as Sword,
 coalesce(top_axe.Level,0) as Axe,
 coalesce(top_club.Level,0) as Club,
 coalesce(top_fishing.Level,0) as Fishing,
 coalesce(world_list.World,'No World') as World,
 coalesce(world_list.PvP_Type, 'No Title World') as PVP_Type
FROM top_distance
LEFT JOIN top_magiclevel
ON top_magiclevel.Name = top_distance.Name
LEFT JOIN top_shielding
ON top_shielding.Name = top_distance.Name
LEFT JOIN top_achievements
ON top_achievements.Name = top_distance.Name
LEFT JOIN top_loyalty
ON top_loyalty.Name = top_distance.Name
LEFT JOIN top_experience
ON top_experience.Name = top_distance.Name
LEFT JOIN top_axe
ON top_axe.Name = top_distance.Name
LEFT JOIN top_sword
ON top_sword.Name = top_distance.Name
LEFT JOIN top_club
ON top_club.Name = top_distance.Name
LEFT JOIN top_fishing
ON top_fishing.Name = top_distance.Name
LEFT JOIN top_fist
ON top_fist.Name = top_distance.Name
LEFT JOIN char_infor
ON top_distance.Name = char_infor.Name
LEFT JOIN world_list
ON world_list.World = top_distance.World
ORDER BY top_distance.Level DESC, top_distance.Rank;

