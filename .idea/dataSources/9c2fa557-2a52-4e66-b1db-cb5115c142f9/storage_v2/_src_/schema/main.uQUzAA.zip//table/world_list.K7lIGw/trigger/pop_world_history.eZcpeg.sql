CREATE TRIGGER pop_world_history
AFTER INSERT ON world_list
BEGIN
INSERT INTO world_list_history (World,Online,Location,PvP_Type,BattlEye,Additional_Information,Extract_data)
 VALUES (new.World,new.Online,new.Location,new.PvP_Type,new.BattlEye,new.Additional_Information,new.Extract_data);
END;

