CREATE VIEW Top as
SELECT
 top_distance.Rank as Rank,
 top_distance.Name as Name,
 top_distance.Level as Distance,
 --char_infor.Level as Char_Level,
 coalesce(top_magiclevel.Level,0) as Magic_Level,
 world_list.World as World,
 world_list.PvP_Type as PVP_Type
 --char_infor.Achievement as Achievement
FROM top_distance
LEFT JOIN top_magiclevel
ON top_magiclevel.Name = top_distance.Name
JOIN world_list
ON world_list.World = top_distance.World
--JOIN char_infor
--ON top_distance.Name = char_infor.Name
ORDER BY top_distance.Level DESC, top_distance.Rank;

