CREATE TRIGGER pop_topDistance_history
AFTER INSERT ON top_distance
BEGIN
INSERT INTO top_distance_history
(
  Rank,
  Name,
  Vocation,
  Level,
  World,
  Link,
  Extract_data
)
 VALUES
(
  new.Rank,
  new.Name,
  new.Vocation,
  new.Level,
  new.World,
  new.Link,
  new.Extract_data
);
END;

